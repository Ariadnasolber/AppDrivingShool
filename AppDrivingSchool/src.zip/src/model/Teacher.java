/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author ariadnasolerbernad
 */
public class Teacher {
    
        private ArrayList<Student> studentsList;

        //Constructor de clase

    public Teacher(ArrayList<Student> studentsList) {
        this.studentsList = studentsList;
    }
        
    //getter
 
   public ArrayList<Student> getStudentsList() {
        return studentsList;
    }

    public void setStudentsList(ArrayList<Student> studentsList) {
        this.studentsList = studentsList;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Teacher{");
        sb.append("studentsList=").append(studentsList);
        sb.append('}');
        return sb.toString();
    }
    
    
    
}
