/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ariadnasolerbernad
 */
public class Employee {
     // Atributos privados
    private float salary;
    private String position;
    
    // Contructor

    public Employee(float salary, String position) {
        this.salary = salary;
        this.position = position;
    }
    
    //Getter y setters

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Employee{");
        sb.append("salary=").append(salary);
        sb.append(", position=").append(position);
        sb.append('}');
        return sb.toString();
    }
    
    
    
}
